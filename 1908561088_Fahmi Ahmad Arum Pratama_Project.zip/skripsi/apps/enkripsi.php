<div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6">
                <h3>Encripsi File</h3>
                <p class="text-subtitle text-muted">Proses encoding informasi untuk melindungi data Anda. Hanya pengguna
                    dengan Enkripsi sisi klien Workspace yang diaktifkan oleh admin dan telah memverifikasi identitas
                    mereka yang dapat membuat file.</p>
            </div>

        </div>

    </div>
    <section class="section">
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">STEGANOGRAFI METODE END OF FILE</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="" method="post" id="form_e">
                                <div class="form-group">
                                    <label for="gambar">Pilih Gambar</label>
                                    <input type="file" class="form-file-input form-control" id="gambar" name="gambar"
                                        onchange="return validasiEkstensi()">
                                </div>
                                <div id="preview"></div>
                                <div class="form-group">
                                    <label for="pesan">Masukan Pesan Yang Akan Disisipkan</label>
                                    <textarea name="pesan" id="pesan" class="form-control" rows="4"></textarea>
                                    <div id="Limit"></div>
                                </div>
                            </form>

                            <button class="btn btn-success" id="proses" onclick="proses()">Proses</button>
                            <button class="btn btn-info" id="reset">Reset</button>
                            <!-- <button class="btn btn-primary" id="download">Download</button> -->

                        </div>
                        <div class="col-md-6">
                            <form action="" method="post" id="form_hasil">
                                <div class="import"></div>
                            </form>
                            <div class="error" style="display: none;"></div>
                            <div class="binary" style="display: none;">
                                <h3>Binary representation of your message</h3>
                                <textarea class="form-control message" style="word-wrap:break-word;"></textarea>
                                
                            </div>
                            <div class="images" style="display: none;">
                                <div class="original" style="display: none;">
                                    <!-- <h5>File Asli</h5> -->
                                    <canvas></canvas>
                                </div>
                                <div class="nulled" style="display: none;">
                                    <h5>Normalized</h5>
                                    <canvas></canvas>
                                </div>
                                <div class="message" style="display: none;">
                                    <h5>Pesan Tersembunyi (Klik Kanan <span
                                            class="glyphicon glyphicon-arrow-right"></span> save as)</h5>
                                    <canvas></canvas>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
</div>
<style>
canvas {
    max-width: 50%;
}

</style>

<script>
$(document).ready(function() {
   
    
    
})


$(document).on('click', '#reset', function() {

    $("#form_e").trigger("reset");
    $("#form_hasil").trigger("reset");
    // $('#preview').innerHTML = '<div id="preview"></div>';
    document.getElementById('preview').innerHTML = '<div id="preview"></div>';
    // document.getElementsByClassName('import').innerHTML = '<div clas="import"></div>';
    // var a = Math.log(10) * 10 * (100 / 25);
    // document.getElementById("hasil").value = a;

});
$(document).on('click', '#download', function() {


    // var download = $('#hasil').val();
    // var form_data = new FormData();
    // form_data.append("download", download);

    // $.ajax({
    //     url: "stg_proses/download.php", //Server api to receive the file
    //     // type: "POST",
    //     dataType: 'script',
    //     cache: false,
    //     contentType: false,
    //     processData: false,
    //     data: form_data,
    //     method: 'GET',
    //     xhrFields: {
    //         responseType: 'blob'
    //     },
    //     success: function(data) {
    //         alert('sukses');
    //         var a = document.createElement('a');
    //         var url = window.URL.createObjectURL(data);
    //         a.href = url;
    //         a.download = 'myfile.pdf';
    //         document.body.append(a);
    //         a.click();
    //         a.remove();
    //         window.URL.revokeObjectURL(url);


    //     },
    //     error: function(response) {
    //         console.log(response.responseText);
    //     }
    // });


});
$(document).ready(function() {
    // $('#download').hide();

})

function validasiEkstensi() {
    var file1 = document.querySelector('#gambar').value;
    
    
    var ext = file1.split('.').pop();

    var text_max = 80;
    $('#Limit').html(text_max + ' Karakter Tersisa');

    $('#pesan').keyup(function() {
        var text_length = $('#pesan').val().length;
        var text_remaining = text_max - text_length;

        $('#Limit').html(text_remaining + ' Karakter Tersisa');
        if (text_length > text_max) {
            Swal.fire(
                            'Peringatan',
                            'Karakter Anda Melebihi Batas',
                            'warning'
                        )
        } else {
            
        }
    });
    

    if (ext === "gif") {
        var file = document.querySelector("input[name=gambar]").files[0];
        $(".images .nulled").hide();
        $(".images .message").hide();

        previewImage(file, ".original canvas", function() {
            $(".images .original").fadeIn();
            $(".images").fadeIn();
        });

        function previewImage(file, canvasSelector, callback) {
            var reader = new FileReader();
            var image = new Image;
            var $canvas = $(canvasSelector);
            var context = $canvas[0].getContext('2d');
            
            

            if (file) {
                reader.readAsDataURL(file);
            }

            reader.onloadend = function() {
                image.src = URL.createObjectURL(file);

                image.onload = function() {
                    $canvas.prop({
                        'width': image.width,
                        'height': image.height
                    });

                    context.drawImage(image, 0, 0);

                    callback();
                }
            }
        }


    } else {
        var inputFile = document.getElementById('gambar');
        var pathFile = inputFile.value;
        var ekstensiOk = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
        if (!ekstensiOk.exec(pathFile)) {
            Swal.fire(
                'Peringatan !!!',
                'Silakan upload file yang dengan ekstensi .jpeg/.jpg/.png/.gif',
                'warning'
            )
            // alert('Silakan upload file yang dengan ekstensi .jpeg/.jpg/.png/.gif');
            inputFile.value = '';
            return false;
        } else {
            // Preview gambar

            if (inputFile.files && inputFile.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('preview').innerHTML = '<img id="fotoku" class="fotoku" src="' + e.target.result +
                        '" style="height:100px"/>';
                };
                reader.readAsDataURL(inputFile.files[0]);
                console.log(ekstensiOk.exec(pathFile));
            }

        }
    }
    // var foto = document.getElementById('fotoku');
    // var lebar = foto.clientWidth;
    // var text_max = lebar /2;
    // $('#Limit').html(text_max + ' Karakter Tersisa');

    // $('#pesan').keyup(function() {
    //     var text_length = $('#pesan').val().length;
    //     var text_remaining = text_max - text_length;

    //     $('#Limit').html(text_remaining + ' Karakter Tersisa');
    //     if (text_length > text_max) {
    //         Swal.fire(
    //                         'Peringatan',
    //                         'Karakter Anda Melebihi Batas',
    //                         'warning'
    //                     )
    //     } else {
            
    //     }
    // });

}

function proses() {
    // $('#modaladd').modal('hide');
    Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Proses Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Proses'
    }).then((result) => {
        if (result.isConfirmed) {

            // var pesan1 = document.getElementById('pesan').val();
            var pesan = $('#pesan').val();
            var gambar = $('#gambar').prop('files')[0];
            var form_data = new FormData();
            form_data.append("pesan", pesan);
            form_data.append("gambar", gambar);

            fileName = document.querySelector('#gambar').value;
            extension = fileName.split('.').pop();

            if (extension === "png") {
                $.ajax({
                    url: "stg_proses/png/encrypt_png.php", //Server api to receive the file
                    type: "POST",
                    dataType: 'script',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success: function(response) {

                        Swal.fire(
                            'Berhasil',
                            'Data Anda Berhasil Di Proses',
                            'success'
                        )
                        $("#form_e").trigger("reset");
                        $("#form_hasil").trigger("reset");
                        // $('#preview').innerHTML = '<div id="preview"></div>';
                        document.getElementById('preview').innerHTML = '<div id="preview"></div>';

                        $(".import").html(response);
                        $('#download').show();

                        // setTimeout(function() {
                        //     window.location = ".";
                        // }, 1000);
                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });
            }
            if (extension === "jpg" || extension === "jpg") {
                $.ajax({
                    url: "stg_proses/jpeg/encrypt_jpeg1.php", //Server api to receive the file
                    type: "POST",
                    dataType: 'script',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success: function(response) {

                        Swal.fire(
                            'Berhasil',
                            'Data Anda Berhasil Di Proses',
                            'success'
                        )
                        $("#form_e").trigger("reset");
                        $("#form_hasil").trigger("reset");
                        // $('#preview').innerHTML = '<div id="preview"></div>';
                        document.getElementById('preview').innerHTML = '<div id="preview"></div>';

                        $(".import").html(response);
                        $('#download').show();

                        // setTimeout(function() {
                        //     window.location = ".";
                        // }, 1000);
                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });

            }

            if (extension === "gif") {
                $(".error").hide();
                $(".binary").hide();

                var text = $("#pesan").val();

                var $originalCanvas = $('.original canvas');
                var $nulledCanvas = $('.nulled canvas');
                var $messageCanvas = $('.message canvas');

                var originalContext = $originalCanvas[0].getContext("2d");
                var nulledContext = $nulledCanvas[0].getContext("2d");
                var messageContext = $messageCanvas[0].getContext("2d");

                var width = $originalCanvas[0].width;
                var height = $originalCanvas[0].height;

                // Check if the image is big enough to hide the message
                if ((text.length * 8) > (width * height * 3)) {
                    $(".error")
                        .text("Text too long for chosen image....")
                        .fadeIn();

                    return;
                }

                $nulledCanvas.prop({
                    'width': width,
                    'height': height
                });

                $messageCanvas.prop({
                    'width': width,
                    'height': height
                });

                // Normalize the original image and draw it
                var original = originalContext.getImageData(0, 0, width, height);
                var pixel = original.data;
                for (var i = 0, n = pixel.length; i < n; i += 4) {
                    for (var offset = 0; offset < 3; offset++) {
                        if (pixel[i + offset] % 2 != 0) {
                            pixel[i + offset]--;
                        }
                    }
                }
                nulledContext.putImageData(original, 0, 0);

                // Convert the message to a binary string
                var binaryMessage = "";
                for (i = 0; i < text.length; i++) {
                    var binaryChar = text[i].charCodeAt(0).toString(2);

                    // Pad with 0 until the binaryChar has a lenght of 8 (1 Byte)
                    while (binaryChar.length < 8) {
                        binaryChar = "0" + binaryChar;
                    }

                    binaryMessage += binaryChar;
                }
                $('.binary textarea').text(binaryMessage);

                // Apply the binary string to the image and draw it
                var message = nulledContext.getImageData(0, 0, width, height);
                pixel = message.data;
                counter = 0;
                for (var i = 0, n = pixel.length; i < n; i += 4) {
                    for (var offset = 0; offset < 3; offset++) {
                        if (counter < binaryMessage.length) {
                            pixel[i + offset] += parseInt(binaryMessage[counter]);
                            counter++;
                        } else {
                            break;
                        }
                    }
                }
                messageContext.putImageData(message, 0, 0);

                // $(".binary").fadeIn();
                // $(".images .nulled").fadeIn();
                Swal.fire(
                    'Berhasil',
                    'Data Anda Berhasil Di Proses',
                    'success'
                )
                $(".images .original").hide();
                $(".images .message").fadeIn();

            }



        } else {
            // $('#modaladd').modal('show');
        }
    });
}
</script>