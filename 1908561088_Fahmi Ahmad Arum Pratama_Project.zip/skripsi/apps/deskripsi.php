<div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6">
                <h3>Decypt File</h3>
                <p class="text-subtitle text-muted">metode yang digunakan untuk mengubah atau menerjemahkan file rahasia
                    yang dienkripsi menjadi pesan asli.</p>
            </div>

        </div>

    </div>
    <section class="section">
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">STEGANOGRAFI METODE END OF FILE</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="" method="post" id="form_d">
                                <div class="form-group">
                                    <label for="gambar">Pilih Gambar</label>
                                    <input type="file" class="form-file-input form-control" id="gambar"
                                        onchange="return validasiEkstensi()">
                                </div>
                                <div id="preview"></div>

                            </form>

                            <button class="btn btn-success" id="proses" onclick="proses()">Proses</button>
                            <button class="btn btn-info" id="reset">Reset</button>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="pesan">Hasil Pesan Yang Telah Di Ekstrak</label>
                                <div class="import"></div>
                            </div>

                            <!-- <div class="form-group">
                                <label for="disabledInput">File Yang Sudah Di Enkripsi</label>
                                <input type="text" class="form-control" id="hasil" readonly>
                            </div> -->
                            <!-- <button class="btn btn-primary"><i class="fa fa-download"></i> Download</button> -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

</div>
<script>
$(document).on('click', '#reset', function() {

    $("#form_d").trigger("reset");
    document.getElementById('preview').innerHTML = '<div id="preview"></div>';
    // var a = Math.log(10) * 10 * (100 / 25);
    // document.getElementById("hasil").value = a;

});
$(document).ready(function() {
    // console.log(Math.E);
    // console.log(Math.LN10);
    // // console.log(Math.LN2);
    // // console.log(Math.LOG10E);
    // // console.log(Math.LOG2E);
    // console.log(Math.PI);
    // // console.log(Math.SQRT1_2);
    // // console.log(Math.SQRT2);
    // console.log(Math.ceil(Math.log(10)));
})

function validasiEkstensi() {
    var inputFile = document.getElementById('gambar');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    if (!ekstensiOk.exec(pathFile)) {
        // alert('Silakan upload file yang dengan ekstensi .jpeg/.jpg/.png/.gif');
        Swal.fire(
            'Peringatan !!!',
            'Silakan upload file yang dengan ekstensi .jpeg/.jpg/.png/.gif',
            'warning'
        )
        inputFile.value = '';
        return false;
    } else {
        // Preview gambar
        if (inputFile.files && inputFile.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('preview').innerHTML = '<img src="' + e.target.result +
                    '" style="height:100px"/>';
            };
            reader.readAsDataURL(inputFile.files[0]);
        }
    }
}

function proses() {
    // $('#modaladd').modal('hide');
    Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Proses Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Proses'
    }).then((result) => {
        if (result.isConfirmed) {

            // var pesan1 = document.getElementById('pesan').val();
            // var pesan = $('#pesan').val();
            var gambar = $('#gambar').prop('files')[0];
            var form_data = new FormData();
            // form_data.append("pesan", pesan);
            form_data.append("gambar", gambar);

            fileName = document.querySelector('#gambar').value;
            extension = fileName.split('.').pop();

            if (extension === "png") {
                $.ajax({
                    url: "stg_proses/png/decrypt_png.php", //Server api to receive the file
                    type: "POST",
                    dataType: 'script',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success: function(response) {
                        
                        Swal.fire(
                            'Berhasil',
                            'Data Anda Berhasil Di Proses',
                            'success'
                        )
                        
                        $("#form_d").trigger("reset");
                        // $("#form_hasil").trigger("reset");
                        // $('#preview').innerHTML = '<div id="preview"></div>';
                        document.getElementById('preview').innerHTML = '<div id="preview"></div>';
                        $(".import").html(response);

                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });
            }
            if (extension === "jpg" || extension === "jpeg") {

                $.ajax({
                    url: "stg_proses/jpeg/decrypt_jpeg.php", //Server api to receive the file
                    type: "POST",
                    dataType: 'script',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success: function(response) {

                        Swal.fire(
                            'Berhasil',
                            'Data Anda Berhasil Di Proses',
                            'success'
                        )

                        $("#form_d").trigger("reset");
                        // $("#form_hasil").trigger("reset");
                        // $('#preview').innerHTML = '<div id="preview"></div>';
                        document.getElementById('preview').innerHTML = '<div id="preview"></div>';
                        $(".import").html(response);

                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });
            }

            if (extension === "gif") {
                $.ajax({
                    url: "stg_proses/gif/decrypt_gif.php", //Server api to receive the file
                    type: "POST",
                    dataType: 'script',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success: function(response) {

                        Swal.fire(
                            'Berhasil',
                            'Data Anda Berhasil Di Proses',
                            'success'
                        )

                        $("#form_d").trigger("reset");
                        // $("#form_hasil").trigger("reset");
                        // $('#preview').innerHTML = '<div id="preview"></div>';
                        document.getElementById('preview').innerHTML = '<div id="preview"></div>';
                        $(".import").html(response);

                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });

            }



        } else {
            // $('#modaladd').modal('show');
        }
    });
}
</script>