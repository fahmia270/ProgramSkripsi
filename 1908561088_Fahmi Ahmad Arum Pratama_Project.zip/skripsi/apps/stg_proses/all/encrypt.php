<?php 

include('functions.php');

$message_to_hide = $_POST['pesan'];
$binary_message = toBin($message_to_hide);
$message_length = strlen($binary_message);
$src = "../image/" . basename($_FILES["gambar"]["name"]);
move_uploaded_file($_FILES["gambar"]["tmp_name"], $src);

$pecah = explode(".", $src);
$ekstensi = $pecah[1];

$im = imagecreatefromjpeg($src);    
// if($ekstensi == "jpeg" || $ekstensi == "jpg"){
// }if($ekstensi == "png"){
//     $im = imagecreatefrompng($src);    
// }

for($x=0;$x<$message_length;$x++){
  $y = $x;
  $rgb = imagecolorat($im,$x,$y);
  $r = ($rgb >>16) & 0xFF;
  $g = ($rgb >>8) & 0xFF;
  $b = $rgb & 0xFF;
  
  $newR = $r;
  $newG = $g;
  $newB = toBin($b);
  $newB[strlen($newB)-1] = $binary_message[$x];
  $newB = toString($newB);
  
  $new_color = imagecolorallocate($im,$newR,$newG,$newB);
  imagesetpixel($im,$x,$y,$new_color);
}
$randomDigit = rand(1, 9999);
// echo $x;
imagepng($im,'hasil'.$randomDigit.'.png');
imagedestroy($im);

?>
<div class="form-group">
    <label for="disabledInput">File Yang Sudah Di Enkripsi</label>
    <input type="text" class="form-control" id="hasil" readonly value="<?= "hasil" . $randomDigit . ".png" ?>">
    <!-- <input type="text" class="form-control" id="hasil" readonly value="<?= $x ?>"> -->
</div>

<a class="btn btn-primary" id="download"
    href="stg_proses/download.php?data=<?= "hasil" . $randomDigit . ".png" ?>">Download</a>