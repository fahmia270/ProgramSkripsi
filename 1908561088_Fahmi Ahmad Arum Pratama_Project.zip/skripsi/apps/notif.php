<script src="notif/sweetalert2.all.min.js"></script>
<script src="notif/sweetalert2.all.js"></script>
<script src="notif/sweetalert2.js"></script>
<script src="notif/sweetalert2.min.js"></script>
<!-- <link rel='stylesheet' href='../css/sweetalert2.min.css'> -->