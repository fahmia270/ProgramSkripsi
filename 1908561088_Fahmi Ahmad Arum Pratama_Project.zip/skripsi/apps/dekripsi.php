<div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6">
                <h3>Decypt File</h3>
                <p class="text-subtitle text-muted">metode yang digunakan untuk mengubah atau menerjemahkan file rahasia
                    yang dienkripsi menjadi pesan asli.</p>
            </div>

        </div>

    </div>
    <section class="section">
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">STEGANOGRAFI METODE END OF FILE</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="" method="post" id="form_d">
                                <div class="form-group">
                                    <label for="gambar">Pilih Gambar</label>
                                    <input type="file" class="form-file-input form-control" id="gambar" name="gambar"
                                        onchange="return validasiEkstensi()">
                                </div>
                                <div id="preview"></div>
                                <div class="decode" style="display: none;">
                                    <canvas></canvas>
                                </div>

                            </form>

                            <button class="btn btn-success" id="proses" onclick="proses()">Proses</button>
                            <button class="btn btn-info" id="reset">Reset</button>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="pesan">Hasil Pesan Yang Telah Di Ekstrak</label>
                                <div class="import"></div>
                                <div class="binary-decode" style="display: none;">
                                    <textarea class="form-control message" rows="4" readonly></textarea>
                                </div>
                            </div>


                            <!-- <div class="form-group">
                                <label for="disabledInput">File Yang Sudah Di Enkripsi</label>
                                <input type="text" class="form-control" id="hasil" readonly>
                            </div> -->
                            <!-- <button class="btn btn-primary"><i class="fa fa-download"></i> Download</button> -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

</div>
<style>
canvas {
    max-width: 50%;
}
</style>
<script>
$(document).on('click', '#reset', function() {

    $("#form_d").trigger("reset");
    document.getElementById('preview').innerHTML = '<div id="preview"></div>';
    // var a = Math.log(10) * 10 * (100 / 25);
    // document.getElementById("hasil").value = a;

});
$(document).ready(function() {
    // console.log(Math.E);
    // console.log(Math.LN10);
    // // console.log(Math.LN2);
    // // console.log(Math.LOG10E);
    // // console.log(Math.LOG2E);
    // console.log(Math.PI);
    // // console.log(Math.SQRT1_2);
    // // console.log(Math.SQRT2);
    // console.log(Math.ceil(Math.log(10)));
})

function validasiEkstensi() {
    var file1 = document.querySelector('#gambar').value;
    var ext = file1.split('.').pop();
    if (ext === "gif" || ext === "jpeg" || ext === "jpg") {
        var file = document.querySelector("input[name=gambar]").files[0];
        previewImage(file, ".decode canvas", function() {
            $(".decode").fadeIn();
        });

        function previewImage(file, canvasSelector, callback) {
            var reader = new FileReader();
            var image = new Image;
            var $canvas = $(canvasSelector);
            var context = $canvas[0].getContext('2d');

            if (file) {
                reader.readAsDataURL(file);
            }

            reader.onloadend = function() {
                image.src = URL.createObjectURL(file);

                image.onload = function() {
                    $canvas.prop({
                        'width': image.width,
                        'height': image.height
                    });

                    context.drawImage(image, 0, 0);

                    callback();
                }
            }
        }


    } else {
        var inputFile = document.getElementById('gambar');
        var pathFile = inputFile.value;
        var ekstensiOk = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
        if (!ekstensiOk.exec(pathFile)) {
            Swal.fire(
                'Peringatan !!!',
                'Silakan upload file yang dengan ekstensi .jpeg/.jpg/.png/.gif',
                'warning'
            )
            // alert('Silakan upload file yang dengan ekstensi .jpeg/.jpg/.png/.gif');
            inputFile.value = '';
            return false;
        } else {
            // Preview gambar

            if (inputFile.files && inputFile.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('preview').innerHTML = '<img id="gm" src="' + e.target.result +
                        '" style="height:100px"/>';
                };
                reader.readAsDataURL(inputFile.files[0]);
                console.log(ekstensiOk.exec(pathFile));
            }

        }
    }
}

function proses() {
    // $('#modaladd').modal('hide');
    Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Proses Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Proses'
    }).then((result) => {
        if (result.isConfirmed) {

            // var pesan1 = document.getElementById('pesan').val();
            // var pesan = $('#pesan').val();
            var gambar = $('#gambar').prop('files')[0];
            var form_data = new FormData();
            // form_data.append("pesan", pesan);
            form_data.append("gambar", gambar);

            fileName = document.querySelector('#gambar').value;
            extension = fileName.split('.').pop();

            if (extension === "png") {
                $.ajax({
                    url: "stg_proses/png/decrypt_png.php", //Server api to receive the file
                    type: "POST",
                    dataType: 'script',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    success: function(response) {
                        if(response == 0){
                            Swal.fire(
                            'Ggaal',
                            'Data Anda Gagal Di Proses',
                            'warning'
                        )
                        }else{
                            Swal.fire(
                            'Berhasil',
                            'Data Anda Berhasil Di Proses',
                            'success'
                        )
                        }
                        // Swal.fire(
                        //     'Berhasil',
                        //     'Data Anda Berhasil Di Proses',
                        //     'success'
                        // )

                        $("#form_d").trigger("reset");
                        // $("#form_hasil").trigger("reset");
                        // $('#preview').innerHTML = '<div id="preview"></div>';
                        document.getElementById('preview').innerHTML = '<div id="preview"></div>';
                        $(".import").html(response);

                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });
            }
            if (extension === "jpg" || extension === "jpeg") {

                var $originalCanvas = $('.decode canvas');
                var originalContext = $originalCanvas[0].getContext("2d");

                var original = originalContext.getImageData(0, 0, $originalCanvas.width(), $originalCanvas
                    .height());
                var binaryMessage = "";
                var pixel = original.data;
                for (var i = 0, n = pixel.length; i < n; i += 4) {
                    for (var offset = 0; offset < 3; offset++) {
                        var value = 0;
                        if (pixel[i + offset] % 2 != 0) {
                            value = 1;
                        }

                        binaryMessage += value;
                    }
                }

                var output = "";
                for (var i = 0; i < binaryMessage.length; i += 8) {
                    var c = 0;
                    for (var j = 0; j < 8; j++) {
                        c <<= 1;
                        c |= parseInt(binaryMessage[i + j]);
                    }

                    output += String.fromCharCode(c);
                }
                Swal.fire(
                    'Berhasil',
                    'Data Anda Berhasil Di Proses',
                    'success'
                )
                // if(output = 0){
                //     $('.binary-decode textarea').text("gagal");
                // }else{
                //     $('.binary-decode textarea').text(output);
                // }
                $('.binary-decode textarea').text(output);
                $('.binary-decode').fadeIn();
                $('.decode').hide();
                $("#form_d").trigger("reset");


            }

            if (extension === "gif") {
                var $originalCanvas = $('.decode canvas');
                var originalContext = $originalCanvas[0].getContext("2d");

                var original = originalContext.getImageData(0, 0, $originalCanvas.width(), $originalCanvas
                    .height());
                var binaryMessage = "";
                var pixel = original.data;
                for (var i = 0, n = pixel.length; i < n; i += 4) {
                    for (var offset = 0; offset < 3; offset++) {
                        var value = 0;
                        if (pixel[i + offset] % 2 != 0) {
                            value = 1;
                        }

                        binaryMessage += value;
                    }
                }

                var output = "";
                for (var i = 0; i < binaryMessage.length; i += 8) {
                    var c = 0;
                    for (var j = 0; j < 8; j++) {
                        c <<= 1;
                        c |= parseInt(binaryMessage[i + j]);
                    }

                    output += String.fromCharCode(c);
                }
                Swal.fire(
                    'Berhasil',
                    'Data Anda Berhasil Di Proses',
                    'success'
                )
                
                $('.binary-decode textarea').text(output);
                $('.binary-decode').fadeIn();
                $('.decode').hide();
                $("#form_d").trigger("reset");
            }



        } else {
            // $('#modaladd').modal('show');
        }
    });
}
</script>