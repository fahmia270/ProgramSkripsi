<?php 

include('functions.php');

$src = basename($_FILES["gambar"]["name"]);

$im = imagecreatefrompng($src);

$real_message = '';
list($width, $height, $type, $attr) = getimagesize($src);
for($x=0;$x<($width * $height);$x++){
  $y = $x;
  $rgb = imagecolorat($im,$x,$y);
  $r = ($rgb >>16) & 0xFF;
  $g = ($rgb >>8) & 0xFF;
  $b = $rgb & 0xFF;
  
  $blue = toBin($b);
  $real_message .= $blue[strlen($blue)-1];
}
$real_message = toString($real_message);
echo ('<textarea name="pesan" id="pesan" class="form-control" rows="4" readonly>' . $real_message . '</textarea>');
// echo $real_message;
die;

?>